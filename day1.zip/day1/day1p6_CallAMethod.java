package com.programs.day1;

public class day1p6_CallAMethod {
	
	/*
	 * no return type methods in java
	 */
	
	/*public void namemethod(){
		System.out.println("This is a sample method !");
				}
	
	public void namemethod1(){
		System.out.println("This is a sample method2 !");
				}
	
	public void namemethod3(){
		System.out.println("This is a sample method3 !");
				}*/




	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Creation of object
		
		Libraryday1 obj = new Libraryday1();
		obj.namemethod();
		obj.namemethod1();
		obj.namemethod3();
		
		


	}

}
