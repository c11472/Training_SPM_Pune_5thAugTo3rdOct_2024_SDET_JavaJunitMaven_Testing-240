package com.programs.day1;
/*
 * For loop
 */
public class DisplayStr10Time {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "Test automation framework";
		
		
		for(int i = 0;i<=9;i++) {
			System.out.println(str);
		}

	}

}
